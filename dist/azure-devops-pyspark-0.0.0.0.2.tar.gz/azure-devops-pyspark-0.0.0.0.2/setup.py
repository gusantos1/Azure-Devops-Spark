from setuptools import setup


text = """
from AzureDevopsSpark import Azure, Agile
from pyspark.sql.functions import datediff #use in agile metrics


devops = Azure('ORGANIZATION', 'PROJECT', 'TOKEN')
devops.filter_columns([
    'IterationPath', 'Id', 'State', 'WorkItemType',
    'CreatedDate', 'ClosedDate', 'Iteration_Start_Date', 'Iteration_End_Date'
]) # Mapped columns that are not in the list passed as an argument will be excluded.

df_members = devops.all_members() #Returns all members in the project.
df_backlog = devops.all_backlog() # Returns all backlog work items within a project.
df_iterations = devops.all_iterations() # Returns all iterations in the project.
df_tags = devops.all_tags() # Returns all tags registered in the project.
df_teams = all_teams(). # Returns all teams registered in the project.
df_items = devops.all_items() # Returns all iterations in the project. It is possible to filter by SQL in the query parameter set to None. 
Ex: Where [System.WorkItemType] = 'Task' AND [System.AssignedTo] = 'Guilherme Silva'. Returns all tasks associated with Guilherme Silva.
"""

setup(
    name = 'azure-devops-pyspark',
    version = '0.0.0.0.2',
    author = 'Guilherme Silva dos Santos',
    author_email = 'gusantos.ok@gmail.com',
    packages = ['AzureDevopsPySpark'],
    description = 'A productive library to extract data from Azure Devops and apply agile metrics.',
    long_description= text,
    long_description_content_type='text/markdown',
    license = 'GNU General Public License v3.0',
    keywords = 'Azure AzureDevops WorkItems PySpark Agile',
    install_requires= [
        'certifi>=2021.10.8'
        'charset-normalizer>=2.0.12'
        'idna>=3.3'
        'requests>=2.27.1'
        'urllib3>=1.26.9',
        'python-dateutil>=2.8.2'
    ]
)