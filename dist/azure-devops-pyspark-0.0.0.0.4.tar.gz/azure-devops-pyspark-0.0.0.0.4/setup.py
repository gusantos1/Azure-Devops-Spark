from setuptools import setup


text = """
## Quick example

```python
from AzureDevopsSpark import Azure, Agile
from pyspark.sql.functions import datediff #use in agile metrics

devops = Azure('ORGANIZATION', 'PROJECT', 'TOKEN')
```

```python
## Filter columns
devops.filter_columns([
    'IterationPath', 'Id', 'State', 'WorkItemType',
    'CreatedDate', 'ClosedDate', 'Iteration_Start_Date', 'Iteration_End_Date'
])


## Pyspark Dataframe data structure
df_members = devops.all_members()
df_backlog = devops.all_backlog()
df_iterations = devops.all_iterations()
df_items = devops.all_items()
```

```python
## Agile Metrics
agile = Agile()

## A new dataframe
df_agil = df.items.join(df_iterations, 'IterationPath')

## Metrics

## Average time between CreatedDate and ClosedDate of items in the last 90 days.
lead_time = lead_time = agile.avg(
    df=df_agil,
    ref=[datediff, 'ClosedDate', 'CreatedDate'], # The day difference between the CreatedDate and ClosedDate of each item.
    iteration_path='IterationPath', # GroupBy.
    new='LeadTimeDays', # New column name.
    literal_filter=['ClosedDate >= 90'], # Filtering items from the last 90 days.
    filters={'WorkItemType': 'Task', 'State': 'Closed'} # Custom filters for metric.
).df
```

"""

setup(
    name = 'azure-devops-pyspark',
    version = '0.0.0.0.4',
    author = 'Guilherme Silva dos Santos',
    author_email = 'gusantos.ok@gmail.com',
    packages = ['AzureDevopsPySpark'],
    description = 'A productive library to extract data from Azure Devops and apply agile metrics.',
    long_description= text,
    long_description_content_type='text/markdown',
    license = 'GNU General Public License v3.0',
    keywords = 'Azure AzureDevops WorkItems PySpark Agile',
    install_requires= [
        'certifi>=2021.10.8'
        'charset-normalizer>=2.0.12'
        'idna>=3.3'
        'requests>=2.27.1'
        'urllib3>=1.26.9',
        'python-dateutil>=2.8.2'
    ]
)